# docs 索引

本目录是 **本项目规格书**：能力面、节点选型、factory API、图规则与排错。  
读本目录即可理解「框架有什么、默认 ReAct 怎么跑」；实现细节以源码为准。

## 怎么读

| 目的 | 从哪开始 |
|------|----------|
| 术语 | [glossary.md](glossary.md) |
| 节点选型 | [node-catalog.md](node-catalog.md) → [node-kit.md](node-kit.md) |
| 默认 ReAct 路径与交付底座 | [examples.md](examples.md) + [flow-orchestration.md](flow-orchestration.md) |
| 能力从哪来 | [capabilities.md](capabilities.md) |
| 排错 | [troubleshooting.md](troubleshooting.md) |

## 文档地图

| 文件 | 用途 |
|------|------|
| [glossary.md](glossary.md) | 术语权威 |
| [flow-graph-rules.md](flow-graph-rules.md) | 图编排硬规则 R-G001+（默认图维护参考） |
| [node-catalog.md](node-catalog.md) | 节点选型（先看这个） |
| [node-kit.md](node-kit.md) | factory API 详表 |
| [flow-orchestration.md](flow-orchestration.md) | 默认 ReAct 编排速查 |
| [examples.md](examples.md) | 默认路径 + 交付底座（多轮会话 / 压缩 / checkpoint） |
| [capabilities.md](capabilities.md) | 运行时能力面（含 `platformToolRefs`） |
| [troubleshooting.md](troubleshooting.md) | 排错 |

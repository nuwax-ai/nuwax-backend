/**
 * DeepAgents Server - ACP Integration
 *
 * This package provides an Agent Client Protocol (ACP) server that wraps
 * DeepAgents, enabling seamless integration with ACP platform hosts.
 *
 * @packageDocumentation
 * @module deepagents-acp
 *
 * @example
 * ```typescript
 * import { DeepAgentsServer, startServer } from "deepagents-acp";
 *
 * // Quick start
 * await startServer({
 *   agents: {
 *     name: "coding-assistant",
 *     description: "AI coding assistant with filesystem access",
 *   },
 *   workspaceRoot: process.cwd(),
 * });
 *
 * // Or create a server instance manually
 * const server = new DeepAgentsServer({
 *   agents: [{
 *     name: "coding-assistant",
 *     description: "AI coding assistant",
 *     skills: ["./skills/"],
 *     memory: ["./.deepagents/AGENTS.md"],
 *   }],
 *   debug: true,
 * });
 *
 * await server.start();
 * ```
 */

// Main server export
export { DeepAgentsServer, startServer } from "./server.js";
export { ACPFilesystemBackend } from "./acp-filesystem-backend.js";

// Type exports
export type {
  DeepAgentConfig,
  DeepAgentsServerOptions,
  DeepAgentsServerHooks,
  SessionConfigurePatch,
  SessionState,
  ToolCallInfo,
  PlanEntry,
  StopReason,
  ACPCapabilities,
  ACPAuthMethod,
  ACPAuthMethodAgent,
  ACPAuthMethodEnvVar,
  ACPAuthMethodTerminal,
  ACPAuthEnvVar,
  ServerEvents,
} from "./types.js";

// Adapter utilities (for advanced use cases)
export {
  acpPromptToHumanMessage,
  langChainMessageToACP,
  langChainContentToACP,
  extractToolCalls,
  todosToPlanEntries,
  generateSessionId,
  generateToolCallId,
  getToolCallKind,
  formatToolCallTitle,
  extractToolCallLocations,
  fileUriToPath,
  pathToFileUri,
} from "./adapter.js";

export {
  markdownEscape,
  preserveRawOutput,
  toolInfoFromToolEvent,
  toolUpdateFromToolResult,
  buildPermissionToolCall,
} from "./acp-tool-presentation.js";
export type {
  AcpToolCallContent,
  ToolPresentationInfo,
  ToolResultPresentation,
} from "./acp-tool-presentation.js";

// Logger utilities
export { Logger, createLogger, nullLogger } from "./logger.js";
export type { LogLevel, LoggerOptions } from "./logger.js";
